/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package DTO;

/**
 *
 * @author artin
 */
public class EmployeeDTO {
    
    private int id; 
    private String name;
    private String adress;

    public EmployeeDTO(int id, String name, String adress) {
        this.id = id;
        this.name = name;
        this.adress = adress;
    }
    
    
    
}

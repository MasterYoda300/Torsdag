/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package facades;

/**
 *
 * @author artin
 */
public class EmployeeFacade {

    public void getEmployeeById() {
    }

    public void getEmployeesByName() {

    }

    public void getAllEmployees() {

    }

    public void getEmployeesWithHighestSalary() {

    }

    public void getcreateEmployee() {

    }
}
